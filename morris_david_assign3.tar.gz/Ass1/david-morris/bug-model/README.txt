CS442 Design Patterns
Spring 2015
PROJECT 1 README FILE

Due Date: Wednesday, February 18, 2015
Submission Date: <DATE YOU SUBMIT, IN FORMAT: Monday, January 1, 2011>
Grace Period Used This Project: 0 Days
Grace Period Remaining: ??? Days
Author(s): David Morris
e-mail(s): dmorris4@binghamton.edu


PURPOSE:

Simulates Movements of a 2015 Volkswagen Bettle

PERCENT COMPLETE:

100%

PARTS THAT ARE NOT COMPLETE:


BUGS:


FILES:

david-morris/
david-morris/bug-model
david-morris/bug-model/src
david-morris/bug-model/src/build.xml
david-morris/bug-model/src/bugModel
david-morris/bug-model/src/bugModel/results
david-morris/bug-model/src/bugModel/results/Results.java
david-morris/bug-model/src/bugModel/results/Display.java
david-morris/bug-model/src/bugModel/results/FileLog.java
david-morris/bug-model/src/bugModel/results/StoreMovements.java
david-morris/bug-model/src/bugModel/util/Debug.java
david-morris/bug-model/src/bugModel/driver
david-morris/bug-model/src/bugModel/driver/Driver.java
david-morris/bug-model/src/bugModel/bug
david-morris/bug-model/src/bugModel/bug/Bug.java
david-morris/bug-model/src/bugModel/bug/AllDirectionsBug.java
david-morris/bug-model/README.txt
david-morris/bug-model/build

SAMPLE OUTPUT:

     [java] 
     [java]  I am a 2015 Volkswagen Bettle Convertible 
     [java] 
     [java] 211233

TO COMPILE:

ant -buildfile src/build.xml

TO RUN:

ant -buildfile src/build.xml run

EXTRA CREDIT:

I implemented methods in Result a range of values from any arbitrary 
two points in the ArrayList

BIBLIOGRAPHY:

http://docs.oracle.com/javase/7/docs/api/java/io/PrintWriter.html

ACKNOWLEDGEMENT:


