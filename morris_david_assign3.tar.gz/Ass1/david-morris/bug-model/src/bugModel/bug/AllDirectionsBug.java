package bugModel.bug;

public interface AllDirectionsBug {
	public int moveRight();
	public int moveLeft();
	public int moveUp();
	public int moveDown();
	public int undoPrev();
    // methods to move right, left, up, down

}
