package bugModel.results;

public interface Display {
    // add appropriate method
	public int writeToScreen();
	public int writeRangeToScreen(int a, int b);
} 
