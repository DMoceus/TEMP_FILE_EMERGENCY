package bugModel.results;

public interface StoreMovements {

	public int addMovement(int direction);
	public int removeLast();

}
