import java.util.Hashtable;
import java.util.ArrayList;


public class AllPrimeQueries{
	private Hashtable<String,ArrayList<Integer>> history;

	public AllPrimeQueries(){
		history = new Hashtable<String,ArrayList<Integer>>();
	}

	private void newEntry(String nameIn){
		ArrayList<Integer> temp = new ArrayList<Integer>();
		temp.add(1);
		history.put(nameIn,temp);
	}
	//Experiment Later with using ArrayList.set to edit elements of the Hashtable
	private void setActive(String nameIn){
		ArrayList<Integer> temp = history.get(nameIn);
		temp.set(0,1);
		history.put(nameIn,temp);
	}
	public void setInactive(String nameIn){
		ArrayList<Integer> temp = history.get(nameIn);
		temp.set(0,0);
		history.put(nameIn,temp);
	}
	
	public boolean registerName(String nameIn){
		if(history.containsKey(nameIn)){
			if(1 == history.get(nameIn).get(0)){
				return false;
			}
			else{
				setActive(nameIn);
				return true;
			}
		}
		else{
			newEntry(nameIn);
			return true;
		}
	}

	public ArrayList<String> getKeys(){
		ArrayList<String> temp = new ArrayList<String>();
		for(String key : history.keySet()){
			temp.add(key);
		}
		return temp;
	}

	public void addElement(String nameIn, Integer value){
		ArrayList<Integer> temp = history.get(nameIn);
		temp.add(value);
		history.put(nameIn,temp);
	}

	public boolean verifyName(String nameIn){
		return history.containsKey(nameIn);
	}

	//IMPORTANT: ONLY CALL IF verifyName(nameIn) RETURNS TRUE
	public ArrayList<Integer> getList(String nameIn){
		return history.get(nameIn);
	}
}
