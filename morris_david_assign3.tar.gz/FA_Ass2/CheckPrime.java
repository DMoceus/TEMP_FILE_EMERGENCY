public final class CheckPrime{
	public static boolean isPrime(int n){
		for(int i=2; i*2 < n; i++){
			if(0 == n%i){
				return false;
			}
		}
		return true;
	}
}
