import java.net.*;
import java.io.*;

public class PrimeServer{
	
	
	public static void main(String[] args) throws IOException{
		if(args.length != 1){
			System.err.println("Usage: java PrimeServer <port-number>");
			System.exit(1);
		}
		AllPrimeQueries history = new AllPrimeQueries();
		PrimeServerThreadSpawner threadManager;
		ServerSocket serverSocket;
		int portNumber;
		try{
			portNumber = Integer.parseInt(args[0]);
		}
		catch(NumberFormatException e){
			System.err.println("Port Number not in Integer Format");
			System.err.println(e.getMessage());
			portNumber = 69;
			System.exit(-1);
		}
				serverSocket = new ServerSocket(portNumber);
				threadManager = new PrimeServerThreadSpawner(serverSocket,history);
				threadManager.start();
		BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
		try{
			String inLine, outLine;
			PrimeServerMenuProtocol handler = new PrimeServerMenuProtocol(history);
			outLine = handler.processInput(null);
			System.out.println(outLine);
			
			while((inLine = stdIn.readLine()) != null){
				outLine = handler.processInput(inLine);
				outLine = outLine.replaceAll("&&&","\n");
				System.out.println(outLine);
				if(outLine.equals("Bye!")){
					break;
				}
			}
			if(!serverSocket.isClosed()){
				serverSocket.close();
			}
			threadManager.join();
		}
		catch(IOException e){
			e.printStackTrace();
		}
		catch(InterruptedException e){
			e.printStackTrace();
		}
		//ADD SERVER MENU HERE
	}
}
