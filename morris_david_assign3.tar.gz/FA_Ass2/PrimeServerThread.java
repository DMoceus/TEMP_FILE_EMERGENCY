import java.net.*;
import java.io.*;

public class PrimeServerThread extends Thread{
	private Socket socket = null;
	private AllPrimeQueries history;
	
	public PrimeServerThread(Socket socket, AllPrimeQueries histIn){
		super("PrimeServerThread on socket: " + Integer.toString(socket.getLocalPort()));
		this.socket = socket;
		this.history = histIn;
	}
	
	public void closeSocket(){
		try{
			socket.close();
		}
		catch(IOException e){}
	}
	
	public void run(){
		try(PrintWriter outStream = new PrintWriter(socket.getOutputStream(), true);
			BufferedReader inStream = new BufferedReader(
				new InputStreamReader(socket.getInputStream()));)
		{

			String inLine, outLine;
			PrimeServerProtocol ppp = new PrimeServerProtocol(history);
			outLine = ppp.processInput(null);
			outStream.println(outLine);
			
			while(!socket.isClosed() && ((inLine = inStream.readLine()) != null)){
				outLine = ppp.processInput(inLine);
				outStream.println(outLine);
				if(outLine.equals("Bye!")){
					break;
				}
			}
			socket.close();
		}
		catch(IOException e){
		}
	}
}
