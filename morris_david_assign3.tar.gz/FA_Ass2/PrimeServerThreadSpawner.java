import java.net.*;
import java.io.*;
import java.util.ArrayList;

public class PrimeServerThreadSpawner extends Thread{
	
	private AllPrimeQueries history;
	public ServerSocket socket;
	private ArrayList<PrimeServerThread> threadList;

	public PrimeServerThreadSpawner(ServerSocket socketIn, AllPrimeQueries histIn){
		super("PrimeServerThreadSpawner on socket: " + Integer.toString(socketIn.getLocalPort()));
		this.history = histIn;
		this.socket = socketIn;
		this.threadList = new ArrayList<PrimeServerThread>();
	}
	
	private void joinThreads(){
		for(PrimeServerThread t : threadList){
			try{
				t.closeSocket();
				t.join();
			}
			catch(InterruptedException e){}
		}
	}
	
	public void run(){
		while(!socket.isClosed()){
			try{
				PrimeServerThread clientThread = new PrimeServerThread(socket.accept(),history);
				clientThread.start();
				threadList.add(clientThread);
			}
			catch(IOException e){
			}
		}
		joinThreads();
		
	}
}
