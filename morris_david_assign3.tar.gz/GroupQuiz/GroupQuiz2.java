public abstract class Feature{
	abstract void create();
}

public class MazeDriver{
	public static void main(String[] args){
		
	}
}
