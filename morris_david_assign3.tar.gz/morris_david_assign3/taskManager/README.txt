CS442 Design Patterns
Spring 2015
PROJECT <3> README FILE

Due Date: <Friday, April 3, 2015>
Submission Date: <Thursday, April 2, 2015>
Grace Period Used This Project: <0> Days
Grace Period Remaining: <???> Days
Author(s): <David Morris>
e-mail(s): <dmorris4@binghamton.edu>


PURPOSE:

[
	Does what Madhu told us to do for Assignment 3.
]

PERCENT COMPLETE:

[
	100%
]

PARTS THAT ARE NOT COMPLETE:

[
	Does not separate "tab" markers by line, but rather by each tab
]

BUGS:

[
]

FILES:

[
	---taskManager
		 ----- README.txt
		 ----- src
		   ---taskManager
		   ----- build.xml
			   ----------driver
					   ----------Driver
			   ----------util
					  ----------FileProcessor
					  ----------MyLogger
			   ----------subject
					  ----------DashBoardSubject
					  ----------Subject		[interface]
			   ----------observers
					  ----------Observer	[interface]
					  ----------ProcessesTab
					  ----------UsersTab
					  ----------PerformanceTab
					  ----------PerformanceTabFilterImpl
					  ----------UsersTabFilterImpl
					  ----------ProcessesTabFilterImpl
			   ----------display
					  ----------DisplayFile	[interface]
			  ----------filter
					  ----------DashboardFilter [interface]
]

SAMPLE OUTPUT:

[
	dmorris4@remote07:~/Documents/Design_Patterns/morris_david_assign3/taskManager$ ant -buildfile src/build.xml -Darg0="new_in1.txt" -Darg1="output.txt" -Darg2="1" run
	Buildfile: /import/linux/home/dmorris4/Documents/Design_Patterns/morris_david_assign3/taskManager/src/build.xml

	jar:

	run:
	   [delete] Deleting: /import/linux/home/dmorris4/Documents/Design_Patterns/morris_david_assign3/taskManager/output.txt

	BUILD SUCCESSFUL
	Total time: 1 second
	dmorris4@remote07:~/Documents/Design_Patterns/morris_david_assign3/taskManager$

]

TO COMPILE:

[
	From The directory of this README.txt
		 ant -buildfile src/build.xml all
]

TO RUN:

[
	From The directory of this README.txt
		ant -buildfile src/build.xml -Darg0="INPUTFILE" -Darg1="OUTPUTFILE" -Darg2="LOGGERVALUE" run
	IMPORTANT NOTES:
		Logger Values are detailed in src/taskManager/util/MyLogger.java
		^ Check the constant names in that file for available input
		OUTPUTFILE will clear itself when named "output.txt" but will append to end if named anything else.
		^ This is intended functionality, and is included as a feature for testing
]

EXTRA CREDIT:

[
]


BIBLIOGRAPHY:

This serves as evidence that we are in no way intending Academic Dishonesty.
<David Morris>

[
	Java Documentation I guess? This assignment was pretty easy, didn't need to look much stuff up.
]

ACKNOWLEDGEMENT:

[
]
