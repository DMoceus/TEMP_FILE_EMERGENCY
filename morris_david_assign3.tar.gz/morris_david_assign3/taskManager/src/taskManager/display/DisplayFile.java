package taskManager.display;

public interface DisplayFile{
	public void writeToFile();
}
