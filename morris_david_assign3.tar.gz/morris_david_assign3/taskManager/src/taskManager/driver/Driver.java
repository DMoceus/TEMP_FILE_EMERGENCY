package taskManager.driver;
import taskManager.util.FileProcessor;
import java.util.ArrayList;
import java.io.IOException;
import taskManager.subject.DashBoardSubject;
import taskManager.observers.*;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import taskManager.util.MyLogger;
import java.lang.NumberFormatException;

public class Driver{
	public static void main(String[] args) throws IOException{
		FileProcessor handler = new FileProcessor();
		DashBoardSubject subj = new DashBoardSubject();
		OutputStreamWriter outWriter = new OutputStreamWriter(new FileOutputStream(args[1],true));
		
		MyLogger logger = MyLogger.getInstance();
		try{
			logger.setDebug(Integer.parseInt(args[2]));
		}
		catch(NumberFormatException e){
			System.err.println("Debug Value not Int");
			System.exit(0);
		}
		Observer performanceObserver = new PerformanceTab(outWriter);
		Observer processesObserver = new ProcessesTab(outWriter);
		Observer usersObserver = new UsersTab(outWriter);

		subj.registerObserver(performanceObserver, new PerformanceTabFilterImpl());
		subj.registerObserver(processesObserver, new ProcessesTabFilterImpl());
		subj.registerObserver(usersObserver, new UsersTabFilterImpl());

		String[] input = handler.processFile(args[0]);
		for(String tab : input){
			subj.notifyAll(tab);
		}
		
		subj.unregisterObserver(performanceObserver);
		subj.unregisterObserver(processesObserver);
		subj.unregisterObserver(usersObserver);

		outWriter.close();
		
	}
}
