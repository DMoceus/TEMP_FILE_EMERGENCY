package taskManager.observers;

public interface Observer{
	public void update(String inString);
}
