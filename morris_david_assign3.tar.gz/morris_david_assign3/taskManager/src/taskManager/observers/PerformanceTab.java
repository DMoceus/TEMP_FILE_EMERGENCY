package taskManager.observers;
import taskManager.display.DisplayFile;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.IOException;
import taskManager.util.MyLogger;

public class PerformanceTab implements Observer, DisplayFile{
	
	private OutputStreamWriter outFile = null;
	private String currentTab = null;
	private MyLogger logger = null;

	public PerformanceTab(OutputStreamWriter streamIn){
		outFile = streamIn;
		logger = MyLogger.getInstance();
	}
	
	public void writeToFile(){
		try{
			if(logger.showsSomething()){
				logger.printMessage(2);
				outFile.write(currentTab);
			}
		}
		catch(IOException e){
			System.err.println("IOException in PerformanceTab.java");
			System.exit(0);
		}
	}

	public void update(String inString){
		String tempString = inString.substring(13);
		logger.printMessage(3);
		currentTab = "---TAB(s) BEGIN---\n---PERFORMANCE---\n";
		String[] tempArray = tempString.split("\\:");
		if(tempArray.length != 7){
			currentTab = currentTab + "---ERROR WITH PERFORMANCE---";
		}
		else{
			currentTab = currentTab + "Memory Total: " + tempArray[0];
			currentTab = currentTab + " Memory Used: " + tempArray[1];
			currentTab = currentTab + " Memory Free: " + tempArray[2];
			currentTab = currentTab + " Memory Cached: " + tempArray[3];
			currentTab = currentTab + " CPU Idle: " + tempArray[4];
			currentTab = currentTab + " CPU User Level: " + tempArray[5];
			currentTab = currentTab + " CPU System Level: " + tempArray[6];
		}
		currentTab = currentTab + "\n\n---TAB(s) END---\n";
		writeToFile();
	}

}
