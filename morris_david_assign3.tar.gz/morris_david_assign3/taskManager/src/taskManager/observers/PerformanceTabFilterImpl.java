package taskManager.observers;
import taskManager.filter.DashboardFilter;

public class PerformanceTabFilterImpl implements DashboardFilter{
	public PerformanceTabFilterImpl(){}
	public boolean check(String inString){
		return inString.startsWith("Performance:");
	}
}
