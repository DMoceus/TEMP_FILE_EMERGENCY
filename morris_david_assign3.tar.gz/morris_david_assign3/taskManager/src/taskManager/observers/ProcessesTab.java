package taskManager.observers;
import taskManager.display.DisplayFile;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.IOException;
import taskManager.util.MyLogger;

public class ProcessesTab implements Observer, DisplayFile{
	
	private OutputStreamWriter outFile = null;
	private String currentTab = null;
	private MyLogger logger;

	public ProcessesTab(OutputStreamWriter streamIn){
		outFile = streamIn;
		logger = MyLogger.getInstance();
	}
	
	public void writeToFile(){
		try{
			if(logger.showsSomething()){
				logger.printMessage(2);
				outFile.write(currentTab);
			}
		}
		catch(IOException e){
			System.err.println("IOException in ProcessesTab.java");
			System.exit(0);
		}
	}

	public void update(String inString){
		String tempString = inString.substring(11);
		logger.printMessage(3);
		currentTab = "---TAB(s) BEGIN---\n---PROCESSES---\n";
		String[] tempArray = tempString.split("\\-");
		String[] processElements;
		currentTab = currentTab + "  PID COMMAND\tUSER\t%CPU %MEM\n";
		
		for(String process : tempArray){
			processElements = process.split("\\:");
			currentTab = currentTab + processElements[0];
			for(int i=0; i<(6-(processElements[0].length())); i++){
				currentTab = currentTab + " ";
			}
			currentTab = currentTab + processElements[1] + "\t";
			currentTab = currentTab + processElements[2] + "\t";
			currentTab = currentTab + processElements[3] + " ";
			currentTab = currentTab + processElements[4] + "\n";
		}

		currentTab = currentTab + "\n---TAB(s) END---\n";
		writeToFile();
	}

}
