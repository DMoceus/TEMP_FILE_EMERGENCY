package taskManager.observers;
import taskManager.filter.DashboardFilter;

public class ProcessesTabFilterImpl implements DashboardFilter{
	public ProcessesTabFilterImpl(){}
	public boolean check(String inString){
		return inString.startsWith("Processes:");
	}
}
