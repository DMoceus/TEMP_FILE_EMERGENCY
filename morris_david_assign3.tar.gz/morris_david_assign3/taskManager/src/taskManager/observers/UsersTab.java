package taskManager.observers;
import taskManager.display.DisplayFile;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.IOException;
import taskManager.util.MyLogger;

public class UsersTab implements Observer, DisplayFile{
	
	private OutputStreamWriter outFile = null;
	private String currentTab = null;
	private MyLogger logger;

	public UsersTab(OutputStreamWriter streamIn){
		outFile = streamIn;
		logger = MyLogger.getInstance();
	}
	
	public void writeToFile(){
		try{
			if(logger.showsSomething()){
				logger.printMessage(2);
				outFile.write(currentTab);
			}
		}
		catch(IOException e){
			System.err.println("IOException in UsersTab.java");
			System.exit(0);
		}
	}

	public void update(String inString){
		String tempString = inString.substring(7);
		logger.printMessage(3);
		currentTab = "---TAB(s) BEGIN---\n---Users---\n";
		String[] tempArray = tempString.split("\\-");
		String[] userDetails;
		for(String user : tempArray){
			userDetails = user.split("\\:");
			currentTab = currentTab + "User: " + userDetails[0] + "  ";
			currentTab = currentTab + "Status: " + userDetails[1] + "\n";
		}

		currentTab = currentTab + "\n---TAB(s) END---\n";
		writeToFile();
	}

}
