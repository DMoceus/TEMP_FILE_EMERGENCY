package taskManager.observers;
import taskManager.filter.DashboardFilter;

public class UsersTabFilterImpl implements DashboardFilter{
	public boolean check(String inString){
		return inString.startsWith("Users:");
	}
}
