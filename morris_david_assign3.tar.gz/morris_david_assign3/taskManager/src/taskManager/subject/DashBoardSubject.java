package taskManager.subject;
import java.util.HashMap;
import taskManager.observers.Observer;
import taskManager.filter.DashboardFilter;
import taskManager.util.MyLogger;

public class DashBoardSubject implements Subject{
	HashMap<Observer,DashboardFilter> obsMap;
	MyLogger logger;
	public DashBoardSubject(){
		obsMap = new HashMap();
		logger = MyLogger.getInstance();
	}
	public void registerObserver(Observer o, DashboardFilter f){
		logger.printMessage(4);
		obsMap.put(o,f);
	}
	public void unregisterObserver(Observer o){
		if(obsMap.containsKey(o)){
			obsMap.remove(o);
		}
	}
	public void notifyAll(String message){
		for(Observer o : obsMap.keySet()){
			if((obsMap.get(o)).check(message)){
				o.update(message);
			}
		}
	}
}
