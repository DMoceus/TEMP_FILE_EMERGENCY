package taskManager.util;
import java.util.ArrayList;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.regex.PatternSyntaxException;

public class FileProcessor{
	public FileProcessor(){}
	public String[] processFile(String inFileName) throws IOException{
		InputStreamReader inFile = null;
		String[] output = null;

		try{
			inFile = new InputStreamReader(new FileInputStream(inFileName));
			String outString = "";
			String parsedString;
			int tempInt;
			char tempChar;
			while(-1 != (tempInt = inFile.read())){
				tempChar = (char)tempInt;
				if('\n' != tempChar){
					outString = outString + tempChar;
				}
			}
			output = outString.split("\\*");
			
		}
		catch(IOException e){
			System.err.println("Problem with File IO in FileProcessor.java");
			System.exit(0);
		}
		catch(PatternSyntaxException e){
			System.err.println("Problem with Regex in FileProcessor.java");
			System.exit(0);
		}
		finally{
			if(null != inFile){
				inFile.close();
			}
		}
		return output;
	}
}
