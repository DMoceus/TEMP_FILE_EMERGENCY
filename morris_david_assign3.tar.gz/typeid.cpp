#include <iostream>
#include <typeinfo>
#include <string>

using namespace std;

int main(int argc, char** argv){
	for(int i=0;i<argc;i++){
		cout << "Input " << i << " type: " << typeid(argv[i]).name() << endl;
	}
}
